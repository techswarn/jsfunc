const name = 'Swarn';

module.exports = name
